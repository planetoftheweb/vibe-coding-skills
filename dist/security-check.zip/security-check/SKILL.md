---
name: security-check
description: "Beginner-friendly, non-invasive security check of your own project: exposed keys (including git history and the browser bundle), open AI functions, database rules, user data leaks, forms, HTTPS, and Google Cloud key and billing settings. Best run in Claude Code on your repo."
license: CC-BY-4.0
---

# Security Check

> **Note:** results are a learning aid, not a professional security audit. Only check projects and sites you own.

Follow the instructions below when the user asks for this. They are written in the user's voice: "I" and "me" mean the user, and "this project" means the repo or folder that is open. If you can't read the project files (for example in a plain chat), ask the user to share their live link plus their code, GitHub repo, or screenshots, and work from that.

Run a beginner-friendly security check on this project. I'm a beginner, so use plain words and explain any tech term the first time you use it.

Follow these safety rules the whole time:
- Only check this project and its own live site. Never test, scan, or probe any other site, including the services it uses. Only look at the parts of those services that belong to this project.
- Look, don't attack. No password guessing, no flooding the site with requests, no hacking tools, and nothing meant to crash or slow it down. Any visit to the live site must be read-only: open pages and read responses, don't submit, change, or delete anything.
- Make no destructive changes. Don't edit, delete, or commit anything, run database changes, or rewrite git history until I pick what to fix.
- If you find a secret key or password, show only the first 4 characters.
- Never ask for my real password.

Step 1. Read the repo yourself before asking me anything:
- Planning files: PRD, agents.md, CLAUDE.md, and DESIGN.md, to learn what the app stores, who logs in, and what logged-in users can do.
- The code, config, and package.json, to see which services and AI APIs it uses.
- Database and storage rules: firebase.json, firestore.rules, storage.rules, Supabase migrations and policies, or whatever this project uses.
- How keys are used: .env files, .env.example, .gitignore, any key written straight into the code, and build config like vite.config or next.config.
- Server code: Firebase or Cloud Functions, API routes, and anything that calls an AI model or fetches a web address.
- Git history: search every past commit, including files that were deleted later, for keys, tokens, .env files, and service account JSON files (files with "private_key" in them).
- Deploy config (Vercel, Netlify, Firebase Hosting, Cloud Run, Lovable, or similar) and the live URL, from the README, config, or planning files.
- Deployed functions: list the functions in main, and look for other branches or backup copies that deploy functions too. If the Firebase CLI is set up, run `firebase functions:list` (it only reads) to see what's actually deployed.

Step 2. Ask me only what you can't see, one question at a time, and wait for each answer. Aim for 0 to 3 questions. Tell me any guess in one sentence so I can confirm it. Good questions: "What's your live URL?" if you can't find it, and "Is the live site the same as this repo, or did you change things in your builder or service dashboards that aren't here?" If database rules aren't in the repo, ask me to paste them from the Firebase or Supabase dashboard.

Step 3. Check these, and tell me which file or page you looked at for each one:
- Exposed keys and secrets: secret keys, passwords, or tokens in the code, the files sent to the browser, committed .env files, or past commits. Check the whole git history, not just today's files, because deleting a file doesn't remove it from history (for example `git log --all -- .env`, or `gitleaks detect --redact` if it's installed). A service account JSON file (a file with "private_key" in it) is a master key to a cloud project and should never be in a repo, even a private one. Some keys are meant to be public, like a Firebase web config or a Supabase anon (public) key. Those are only safe if the rules are locked down, so tell me which kind each key is. Secret keys, like a Supabase service role key, an OpenAI or Gemini API key, or a Stripe secret key, must never reach the browser or a public repo. Check that .gitignore covers .env and every variant like .env.local and .env.production (a `.env*` line, plus `!.env.example` if I keep one). Run `git check-ignore -v .env .env.local .env.production` even if those files don't exist yet, and list any .env file git would still pick up. Tell me if the repo is public, since then everyone can see every file and past commit.
- Server keys in the browser: anything the browser downloads is public, even inside a minified file. Check whether a secret key gets copied into the built site, for example through env names that start with VITE_ or NEXT_PUBLIC_, a vite.config that uses define to put process.env values into the code, or code that hands the whole import.meta.env or process.env object to the browser. If there's a built folder like dist, build, or .next, search it for secret key names like GEMINI_API_KEY or OPENAI_API_KEY. Secret keys belong in server code only.
- Paid features anyone can use: can a stranger call a function or API route that uses an AI model or another paid service without signing in? Is there a rate limit (a cap on how often one person can call it) or Firebase App Check? If not, anyone could run up my bill. Also look for open file proxies and server code that fetches any web address a user sends. That's called SSRF (server-side request forgery): a stranger could make my server download things for them, or reach private addresses only my server can see.
- Database and storage rules: can someone who isn't logged in read, add, change, or delete data or files? Is Row Level Security turned on for every Supabase table? Flag any rule that lets anyone read or write everything.
- One user seeing another user's data: do the rules and code check that the logged-in user owns the data before showing or changing it? Could someone change an ID in the web address or a request to reach another user's data?
- Forms and input: does the server check what people type, not just the browser? Does the app show user text safely, or could it run code people type in (for example raw HTML)? Is there anything to stop bots from flooding a public form?
- HTTPS: does the deploy config force https? Are any images or scripts loaded over plain http?
- Leftover admin pages and debug info: admin or test pages anyone can open, error messages that show code or database details, and debug logging of private data.
- Google Cloud settings (if this project uses Firebase, Gemini, AI Studio, or Google Cloud): you can't see these, so give me a short list to check myself in the Google Cloud console. An AI Studio project is a real Google Cloud project with billing. One leaked key can get the whole project suspended, which takes the whole site down (Hosting, database, and functions), not just the key. Every API key should have an application restriction (my site, for a browser key) and an API restriction (only the APIs it needs). A Gemini key should only allow the Generative Language API and should live only in server code. In Google AI Studio, look for keys labeled Unrestricted. Turn off APIs I don't use, since each one is something a leaked key can reach. Set a budget alert in Billing so I hear about a surprise bill in hours, not at the end of the month.
- Replaced keys and deployed functions: if a key was ever replaced, check that every function uses the new one. Deleting a key isn't enough if the old key is still the newest secret version (for example in Secret Manager), so ask me to confirm the new key is the newest version and the old versions are disabled. Compare the deployed functions with the ones in main, and flag any that aren't in main or came from a branch or backup, since those can miss a redeploy.
- Spending limits for every paid service: list each paid service this project uses (for example Supabase, OpenAI, Anthropic, Stripe, or an email service) and tell me where to set a budget alert or spending cap in each one, since a leaked key or open function shows up first on the bill.
- Offline plan: ask me what happens if my site goes offline. Is there a way for users to keep working (like saving or exporting their work), and do I know where my data lives and have a recent copy?
- Optional live check: if you can reach the live URL, confirm read-only what you found, like https, a key showing up in the page source, or an admin page that opens. Say which findings you confirmed live.

Rate how serious each problem is:
- High: a stranger could steal data, change other people's data, run up charges on my accounts, or get my whole cloud project suspended. Fix it before sharing the link.
- Medium: a real risk, but harder to use or less harmful.
- Low: good practice. Fix it when you can.

Reply in this format:
What works: 2 or 3 things you checked that are already safe, one sentence each.
What to fix: up to 5 problems, numbered, worst first. For each one: a short title, the rating (High, Medium, or Low), the file it's in, what you found in one sentence, what a stranger could do with it in one plain sentence, and how I can check it myself.
How to improve it: 3 suggestions, most important first. Each is one short sentence (under 20 words) that starts with an action word like Move, Lock, Turn on, Remove, Hide, or Check.
Example: Lock firestore.rules so each user can only read and write their own entries.
If a secret key was ever committed or public, tell me to do these in order: 1. First delete the key, or make a new one and delete the old one, in that service, because removing it from the code isn't enough. 2. If the key is stored as a secret, add the new key as a new secret version, redeploy every function that uses it (including ones deployed from a branch or backup), then disable the old versions. 3. Then clean it out of my code and git history. 4. Then check that service's billing and usage pages for anything I don't recognize.
If my cloud project was suspended, tell me to appeal from the suspension email as the project owner, not delete the flagged resources, reply to the support case with what I fixed, and file only one appeal.

Then ask me which problems I want to fix (at least 2, or all of them) and wait. Before you start, warn me that fixing can use a lot of credits, so I can fix things myself instead. Fix only the problems I picked, change nothing else, add no new features, and don't redesign anything. Don't delete data, turn off login, or rewrite git history yourself. If history needs cleaning, tell me how. Show me the diff and explain each change in one sentence before you commit, and wait for my OK. Then tell me how to check that the site still works for both a logged-in user and a visitor.

## Retest

When the user says they made fixes, run the check again and report what got better and what still needs work, in the same format.
